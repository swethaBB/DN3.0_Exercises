

public class DecoratorPatternTest {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Hello, this is a notification!");
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        smsNotifier.send("Hello, this is a notification!");
        Notifier slackNotifier = new SlackNotifierDecorator(emailNotifier);
        slackNotifier.send("Hello, this is a notification!");
        Notifier combinedNotifier = new SMSNotifierDecorator(new SlackNotifierDecorator(emailNotifier));
        combinedNotifier.send("Hello, this is a notification!");
    }
}

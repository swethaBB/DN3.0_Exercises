
public class ObserverPatternDemo {
 public static void main(String[] args) {
     StockMarket stockMarket = new StockMarket("AAPL");

     MobileApp mobileApp = new MobileApp("Mobile Stock Tracker");
     WebApp webApp = new WebApp("Web Stock Monitor");

     stockMarket.registerObserver(mobileApp);
     stockMarket.registerObserver(webApp);

     System.out.println("Setting stock price to $150.00");
     stockMarket.setStockPrice(150.00);
     System.out.println();

     System.out.println("Setting stock price to $155.25");
     stockMarket.setStockPrice(155.25);
     System.out.println();

     stockMarket.deregisterObserver(mobileApp);
     System.out.println("Deregistered Mobile App.");
     
     System.out.println("Setting stock price to $160.75");
     stockMarket.setStockPrice(160.75);
 }
}

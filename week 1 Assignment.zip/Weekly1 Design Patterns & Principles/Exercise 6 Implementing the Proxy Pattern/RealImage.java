

public class RealImage implements Image {
 private String fileName;

 public RealImage(String fileName) {
     loadFromRemoteServer();
     this.fileName = fileName;
 }

 private void loadFromRemoteServer() {
     System.out.println("Loading image from remote server: " + fileName);
 }

 @Override
 public void display() {
     System.out.println("Displaying image: " + fileName);
 }
}

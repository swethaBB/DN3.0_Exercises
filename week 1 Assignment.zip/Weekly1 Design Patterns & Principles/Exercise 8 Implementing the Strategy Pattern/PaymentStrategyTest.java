

public class PaymentStrategyTest {
 public static void main(String[] args) {
     PaymentContext context = new PaymentContext();
     PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9012-3456");
     context.setPaymentStrategy(creditCardPayment);
     context.executePayment(500); 
     PaymentStrategy payPalPayment = new PayPalPayment("user@example.com");
     context.setPaymentStrategy(payPalPayment);
     context.executePayment(300); 
 }
}


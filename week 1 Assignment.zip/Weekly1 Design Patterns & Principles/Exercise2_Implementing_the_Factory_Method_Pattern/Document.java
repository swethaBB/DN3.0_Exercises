

public interface Document {
    void create();
}



public class BuilderPatternTest {
    public static void main(String[] args) {
        Computer gamingPC = new Computer.Builder("Intel i9", 32)
                .storage(2000)
                .GPU("NVIDIA RTX 3080")
                .OS("Windows 10")
                .build();

        Computer officePC = new Computer.Builder("AMD Ryzen 5", 16)
                .storage(512)
                .build();

        System.out.println(gamingPC);
        System.out.println(officePC);
    }
}



public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook(new Book(1, "To Kill a Mockingbird", "Harper Lee"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "Moby Dick", "Herman Melville"));
        library.addBook(new Book(4, "The Great Gatsby", "F. Scott Fitzgerald"));
        Book foundBookLinear = library.linearSearchByTitle("1984");
        if (foundBookLinear != null) {
            System.out.println("Found (Linear Search): " + foundBookLinear.title + " by " + foundBookLinear.author);
        } else {
            System.out.println("Book not found (Linear Search).");
        }
        Book foundBookBinary = library.binarySearchByTitle("Moby Dick");
        if (foundBookBinary != null) {
            System.out.println("Found (Binary Search): " + foundBookBinary.title + " by " + foundBookBinary.author);
        } else {
            System.out.println("Book not found (Binary Search).");
        }
    }
}

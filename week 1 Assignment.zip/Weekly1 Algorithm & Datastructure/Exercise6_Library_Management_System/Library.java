
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Library {
    private ArrayList<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }
    public void addBook(Book book) {
        books.add(book);
    }
    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book; 
            }
        }
        return null;
    }
    public Book binarySearchByTitle(String title) {
        Collections.sort(books, Comparator.comparing(b -> b.title));
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books.get(mid).title.compareToIgnoreCase(title);

            if (comparison == 0) {
                return books.get(mid); 
            } else if (comparison < 0) {
                left = mid + 1; 
            } else {
                right = mid - 1; 
            }
        }
        return null; 
    }
}

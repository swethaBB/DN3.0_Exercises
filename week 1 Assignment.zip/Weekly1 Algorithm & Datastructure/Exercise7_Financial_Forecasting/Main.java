

public class Main {
    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        
        double principal = 1000; 
        double growthRate = 0.05;
        int years = 10; 
        
        double futureValue = forecasting.calculateFutureValue(principal, growthRate, years);
        System.out.println("Future Value: " + futureValue);
    }
}






public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Smartphone", "Electronics"),
            new Product(3, "Table", "Furniture"),
            new Product(4, "Chair", "Furniture"),
            new Product(5, "Headphones", "Electronics")
        };

        // Linear Search Test
        Product linearSearchResult = LinearSearch.linearSearch(products, "Chair");
        if (linearSearchResult != null) {
            System.out.println("Linear Search Found: " + linearSearchResult);
        } else {
            System.out.println("Linear Search: Product not found");
        }

        // Binary Search Test
        Product binarySearchResult = BinarySearch.binarySearch(products, "Chair");
        if (binarySearchResult != null) {
            System.out.println("Binary Search Found: " + binarySearchResult);
        } else {
            System.out.println("Binary Search: Product not found");
        }
    }
}

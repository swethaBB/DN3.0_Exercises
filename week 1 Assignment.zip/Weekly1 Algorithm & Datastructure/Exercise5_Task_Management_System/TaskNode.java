

class TaskNode {
    Task task;
    TaskNode next;

    TaskNode(Task task) {
        this.task = task;
        this.next = null;
    }
}

class TaskManager {
    private TaskNode head;
    public TaskManager() {
        this.head = null;
    }
    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (head == null) {
            head = newNode;
        } else {
            TaskNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }
    public Task searchTask(int taskId) {
        TaskNode current = head;
        while (current != null) {
            if (current.task.taskId == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }
    public void traverseTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println("Task ID: " + current.task.taskId + ", Task Name: " + current.task.taskName + ", Status: " + current.task.status);
            current = current.next;
        }
    }
    public boolean deleteTask(int taskId) {
        TaskNode current = head;
        TaskNode prev = null;

        while (current != null) {
            if (current.task.taskId == taskId) {
                if (prev != null) {
                    prev.next = current.next;
                } else {
                    head = current.next; 
                }
                return true; 
            }
            prev = current;
            current = current.next;
        }
        return false;
    }
}

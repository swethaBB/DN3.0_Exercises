
public class Main {
    public static void main(String[] args) {
        TaskManager taskManager = new TaskManager();
        taskManager.addTask(new Task(1, "Write report", "Pending"));
        taskManager.addTask(new Task(2, "Fix bugs", "In Progress"));
        taskManager.addTask(new Task(3, "Review code", "Completed"));
        System.out.println("All Tasks:");
        taskManager.traverseTasks();
        Task foundTask = taskManager.searchTask(2);
        if (foundTask != null) {
            System.out.println("Found Task: " + foundTask.taskName);
        } else {
            System.out.println("Task not found.");
        }
        if (taskManager.deleteTask(1)) {
            System.out.println("Task with ID 1 deleted.");
        } else {
            System.out.println("Task with ID 1 not found.");
        }
        System.out.println("Tasks after deletion:");
        taskManager.traverseTasks();
    }
}

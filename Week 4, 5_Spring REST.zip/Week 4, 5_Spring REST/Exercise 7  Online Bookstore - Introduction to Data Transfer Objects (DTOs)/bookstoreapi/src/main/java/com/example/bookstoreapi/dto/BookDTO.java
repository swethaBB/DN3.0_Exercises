package com.example.bookstoreapi.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BookDTO {

    @JsonProperty("book_id")
    private Long id;

    @JsonProperty("book_title")
    private String title;

    private String author;

    private double price;

    @JsonProperty("book_isbn")
    private String isbn;
}
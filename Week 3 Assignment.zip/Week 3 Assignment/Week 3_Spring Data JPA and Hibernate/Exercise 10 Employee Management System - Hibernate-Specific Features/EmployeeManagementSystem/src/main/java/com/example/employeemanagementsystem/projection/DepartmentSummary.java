package com.example.employeemanagementsystem.projection;

public interface DepartmentSummary {

    Long getId();
    String getName();
}
